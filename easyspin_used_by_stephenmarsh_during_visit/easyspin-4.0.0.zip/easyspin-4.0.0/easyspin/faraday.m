% faraday  Faraday constant 
%
%   F = faraday
%   [F,sigma] = faraday
%
%   Returns the Faraday constant in
%   C mol^-1. sigma is the standard
%   uncertainty (2006 CODATA).
