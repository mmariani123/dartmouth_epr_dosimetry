% bohrrad  Bohr radius 
%
%   r = bohrrad
%   [r,sigma] = bohrrad
%
%   Returns the Bohr radius in units of meters.
%   sigma is the standard uncertainty (2006 CODATA).
