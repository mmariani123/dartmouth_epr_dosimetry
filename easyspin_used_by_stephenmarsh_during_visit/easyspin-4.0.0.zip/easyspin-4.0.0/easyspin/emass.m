% emass  Electron mass 
%
%   me = emass
%   [me,sigma] = emass
%
%   Returns the mass of the electron in kg.
%   sigma is the standard uncertainty (2006 CODATA).
