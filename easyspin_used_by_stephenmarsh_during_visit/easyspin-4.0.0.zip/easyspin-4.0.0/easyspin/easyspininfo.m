% easyspininfo  Installation information and test 
%
%   Tests the EasySpin installation and prints
%   release details.
