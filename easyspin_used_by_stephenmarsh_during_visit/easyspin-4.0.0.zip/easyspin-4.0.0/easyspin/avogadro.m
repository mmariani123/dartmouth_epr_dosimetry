% avogadro  Avogadro number 
%
%   N = avogadro
%   [N,sigma] = avogadro
%
%   Returns the Avogadro constant
%   in mol^-1. sigma is the standard
%   uncertainty (2006 CODATA).
