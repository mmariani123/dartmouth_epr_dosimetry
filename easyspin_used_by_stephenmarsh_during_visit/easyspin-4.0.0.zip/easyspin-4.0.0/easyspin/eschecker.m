% ESCHECKER   EasySpin expiry checker
%
%    eslicense
%
%   Checks the expiry of EasySpin
