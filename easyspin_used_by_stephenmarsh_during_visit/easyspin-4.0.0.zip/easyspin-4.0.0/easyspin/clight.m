% clight  Speed of light 
% 
%   c = clight
%
%   Returns the vacuum speed of light in
%   meters per second.
