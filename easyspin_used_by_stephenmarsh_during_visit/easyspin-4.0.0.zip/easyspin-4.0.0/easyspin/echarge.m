% echarge  Elementary charge 
%
%   e = echarge
%   [e,sigma] = echarge
%
%   Returns the elementary charge
%   in C. sigma is the standard
%   uncertainty (2006 CODATA).
